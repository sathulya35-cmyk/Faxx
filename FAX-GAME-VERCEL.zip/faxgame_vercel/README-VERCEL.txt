FAX GAME — Vercel static deployment

DEPLOY:
1. Extract this ZIP on your phone/computer.
2. Upload the files in this folder to a GitHub repository (index.html must be at the repository root).
3. In Vercel choose Add New -> Project and import that GitHub repository.
4. Framework Preset: Other
5. Build Command: leave empty
6. Output Directory: . (or leave the default if Vercel detects the static site)
7. Click Deploy.

IMPORTANT:
- This package deploys the website frontend to Vercel.
- The cloud session API is NOT deployed by this static package. The existing FastAPI broker must run on a separate Python host, or be converted to Vercel-compatible serverless functions. Until configured, the cloud session button cannot create real sessions.
- Game cards open official game pages; they do not stream PC games in the browser by themselves.
- To make the session button work, configure the frontend to call your separate broker URL and enable suitable CORS on the broker.
